create function hapuspesanan()
  returns trigger
language plpgsql
as $$
BEGIN
  Delete from pesanan_customer where id_pesanan = tg_nargs;
 Delete from pesanan_room where id_pesanan = tg_nargs;
 return new;
 end;
$$;


create function hapuscustomer()
  returns trigger
language plpgsql
as $$
BEGIN
  delete from customer where id = old.id_customer;
  delete from pesanan where id = old.id_pesanan;
 return new;
 end;
$$;

